<h1 align="center">⬜⬛🟥🟦🟧🟨🟩🟪🟫 wordle-custom-theme-extension</h1>
<p align="center">A multi-browser extension to use custom colors and symbols on Wordle (https://www.powerlanguage.co.uk/wordle/)</p>
<h3 align="center">🙋‍♂️ Made by <a href="https://twitter.com/ken_bellows">@ken_bellows</a></h3>
<p align="center">
  <a href="https://www.buymeacoffee.com/kenbellows" target="_blank">
    <img src="https://cdn.buymeacoffee.com/buttons/v2/default-violet.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" >
  </a>
</p>

**Now supports NYT site!**

## License

MIT © [Ken Bellows](https://kenbellows.com)
